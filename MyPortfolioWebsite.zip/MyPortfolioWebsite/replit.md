# Portfolio Website

## Overview

This is a personal portfolio website for Venkata Sri Sai Kiran, a Data Science enthusiast and Computer Science Engineering student. The website showcases projects, skills, experience, and provides a contact mechanism for potential collaborators and employers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a traditional Flask web application architecture with the following key characteristics:

### Frontend Architecture
- **Template Engine**: Jinja2 templating with Flask
- **CSS Framework**: TailwindCSS for responsive design and styling
- **JavaScript**: Vanilla JavaScript for interactive features (dark mode, animations, form handling)
- **Responsive Design**: Mobile-first approach with responsive grid layouts

### Backend Architecture
- **Web Framework**: Flask (Python) with Blueprint pattern for modular organization
- **Application Structure**: Blueprints separate main pages from contact functionality
- **Session Management**: Flask sessions with configurable secret key
- **Email Service**: Flask-Mail integration for contact form submissions

## Key Components

### Core Application (app.py)
- Flask application factory pattern
- Environment-based configuration for email settings
- Blueprint registration for modular routing
- Logging configuration for debugging

### Blueprints
1. **Main Blueprint** (`blueprints/main.py`):
   - Homepage with personal information display
   - JSON data loading for dynamic content
   - Static file serving

2. **Contact Blueprint** (`blueprints/contact.py`):
   - Contact form handling with validation
   - Email sending functionality
   - Flash messaging for user feedback

### Data Management
- **JSON Files**: Static data storage in `data/` directory
  - `blog.json`: Blog posts with metadata
  - `projects.json`: Project portfolio with technical details
- **Template Variables**: Dynamic content injection from JSON data

### Frontend Components
- **Base Template**: Shared layout with navigation, dark mode toggle, and responsive design
- **Page Templates**: Specialized templates for different sections (index, projects, blog, contact)
- **Styling**: TailwindCSS with custom animations and hover effects
- **JavaScript**: Interactive features including typewriter effects, scroll animations, and form validation

## Data Flow

1. **Request Routing**: Flask routes requests to appropriate blueprints
2. **Data Loading**: JSON files are loaded and processed in route handlers
3. **Template Rendering**: Jinja2 templates receive data and render HTML
4. **Contact Form**: Form submissions trigger email sending via Flask-Mail
5. **Static Assets**: CSS, JavaScript, and other assets served directly

## External Dependencies

### Python Packages
- **Flask**: Web framework
- **Flask-Mail**: Email functionality for contact forms

### Frontend Libraries
- **TailwindCSS**: CSS framework (CDN)
- **Font Awesome**: Icon library (CDN)
- **Google Fonts**: Typography (Inter font family)

### Email Service
- **SMTP Integration**: Configurable email server (default: Gmail SMTP)
- **Environment Variables**: Email credentials and configuration

## Deployment Strategy

### Environment Configuration
- Environment variables for sensitive data (email credentials, session secrets)
- Debug mode configurable for development vs production
- Host configuration for local development (0.0.0.0:5000)

### File Structure
- Static assets organized in `static/` directory
- Templates in `templates/` directory with inheritance pattern
- Data files in `data/` directory for easy content management
- Modular blueprint organization for scalability

### Production Considerations
- Session secret should be changed from default development value
- Email configuration requires proper SMTP credentials
- Static file serving should be handled by web server in production
- Environment-specific configuration management needed

The architecture prioritizes simplicity and maintainability while providing a professional portfolio presentation with interactive features and contact capabilities.