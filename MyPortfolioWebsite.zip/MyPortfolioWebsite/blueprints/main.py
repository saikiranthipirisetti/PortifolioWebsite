import json
import os
from flask import Blueprint, render_template, send_from_directory, current_app

main_bp = Blueprint('main', __name__)

def load_json_data(filename):
    """Load data from JSON files"""
    try:
        with open(f'data/{filename}', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

@main_bp.route('/')
def index():
    """Homepage with personal introduction and overview"""
    # Personal information
    personal_info = {
        'name': 'Venkata Sri Sai Kiran',
        'title': 'Data Science Enthusiast & Computer Science Engineering Student',
        'location': 'Tanuku, Andhra Pradesh',
        'phone': '9133186913',
        'email': 'thiprisettisaikiran4291@gmail.com',
        'linkedin': 'linkedin.com/in/saikiranthipirisetti',
        'github': 'github.com/saikiranthipirisetti',
        'about': 'Passionate Data Science student with hands-on experience in machine learning, data analytics, digital marketing, and business intelligence. Currently pursuing B.Tech in Computer Science & Engineering with a focus on predictive modeling, data-driven solutions, and digital marketing strategies.'
    }
    
    # Skills data
    skills = {
        'programming': ['Python', 'Java', 'C++', 'C', 'R', 'SQL', 'MySQL'],
        'web_development': ['HTML', 'CSS', 'JavaScript'],
        'digital_marketing': ['SEO', 'Blogging', 'Affiliate Marketing', 'Paid Ads', 'Google Analytics'],
        'bi_visualization': ['Tableau', 'Excel'],
        'data_analytics': ['Data Mining', 'Predictive Analytics', 'Machine Learning', 'Pandas', 'Scikit-learn'],
        'soft_skills': ['Leadership', 'Team Work', 'Problem-Solving', 'Communication', 'Project Management', 'Adaptability']
    }
    
    # Work experience
    experience = [
        {
            'company': 'Academor',
            'position': 'Data Science Intern',
            'duration': 'May 2024 - Jul 2024',
            'location': 'Remote',
            'technologies': ['Python', 'Tableau'],
            'achievements': [
                'Designed machine learning models analyzing credit history and property area',
                'Customized Loan Prediction Project using Python, Pandas, Tableau, Google Colab',
                'Improved experience and productivity through hands-on practice',
                'Successfully completed Data Science course with Academor'
            ]
        }
    ]
    
    # Education
    education = [
        {
            'institution': 'Lovely Professional University',
            'degree': 'B.Tech in Computer Science & Engineering',
            'duration': '2022 – 2026',
            'location': 'Phagwara, Punjab',
            'grade': 'CGPA: 8.00'
        },
        {
            'institution': 'Sasi Jr College',
            'degree': '12th Grade',
            'duration': '2019 – 2022',
            'location': 'Tanuku, Andhra Pradesh',
            'grade': 'Percentage: 96%'
        },
        {
            'institution': 'Sasi English Medium High School',
            'degree': '10th Grade',
            'duration': '2019 – 2020',
            'location': 'Tanuku, Andhra Pradesh',
            'grade': 'CGPA: 10'
        }
    ]
    
    # Certificates
    certificates = [
        {
            'name': 'Cloud Computing',
            'issuer': 'NPTEL',
            'date': 'Dec 2024'
        },
        {
            'name': 'Data Analysis with Tableau',
            'issuer': 'Coursera',
            'date': 'Nov 2024'
        },
        {
            'name': 'Supervised Machine Learning: Regression & Classification',
            'issuer': 'Coursera',
            'date': 'Nov 2024'
        },
        {
            'name': 'Mastering Data Structures & Algorithms using C and C++',
            'issuer': 'Udemy',
            'date': 'Jun 2024'
        },
        {
            'name': 'Programming in C++: A Hands-on Introduction',
            'issuer': 'Coursera',
            'date': 'Mar 2024'
        },
        {
            'name': 'Supervised Machine Learning - Machine Learning Algorithms',
            'issuer': 'Coursera',
            'date': 'Jan 2024'
        },
        {
            'name': 'The Bits and Bytes of Computer Networking',
            'issuer': 'Coursera',
            'date': 'Sep 2023'
        },
        {
            'name': 'Become a Data Scientist',
            'issuer': 'LinkedIn',
            'date': 'Feb 2023'
        }
    ]
    
    # Load projects data
    projects = load_json_data('projects.json')[:3]  # Show only top 3 projects on homepage
    
    return render_template('index.html', 
                         personal_info=personal_info,
                         skills=skills,
                         experience=experience,
                         education=education,
                         certificates=certificates,
                         projects=projects)

@main_bp.route('/projects')
def projects():
    """Projects showcase page"""
    projects_data = load_json_data('projects.json')
    return render_template('projects.html', projects=projects_data)

@main_bp.route('/blog')
def blog():
    """Blog section page"""
    blog_posts = load_json_data('blog.json')
    return render_template('blog.html', posts=blog_posts)

@main_bp.route('/download-cv')
def download_cv():
    """Download CV endpoint"""
    try:
        return send_from_directory('static/assets', 'cv.pdf', as_attachment=True, 
                                 download_name='Venkata_Sri_Sai_Kiran_CV.pdf')
    except FileNotFoundError:
        current_app.logger.error("CV file not found")
        return "CV file not available for download", 404

@main_bp.route('/view-cv')
def view_cv():
    """View CV in browser endpoint"""
    try:
        return send_from_directory('static/assets', 'cv.pdf', as_attachment=False)
    except FileNotFoundError:
        current_app.logger.error("CV file not found")
        return "CV file not available for viewing", 404
