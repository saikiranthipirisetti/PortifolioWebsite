from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from flask_mail import Message
from app import mail
import logging

contact_bp = Blueprint('contact', __name__)

@contact_bp.route('/', methods=['GET', 'POST'])
def contact():
    """Contact form page"""
    if request.method == 'POST':
        # Get form data
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()
        
        # Basic validation
        if not all([name, email, subject, message]):
            flash('All fields are required.', 'error')
            return render_template('contact.html')
        
        try:
            # Create email message
            msg = Message(
                subject=f"Portfolio Contact: {subject}",
                recipients=['thiprisettisaikiran4291@gmail.com'],
                body=f"""
New contact form submission:

Name: {name}
Email: {email}
Subject: {subject}

Message:
{message}

---
This message was sent through the portfolio contact form.
                """,
                reply_to=email
            )
            
            # Send email
            mail.send(msg)
            
            # Log the contact attempt
            current_app.logger.info(f"Contact form submitted by {name} ({email})")
            
            flash('Thank you for your message! I will get back to you soon.', 'success')
            return redirect(url_for('contact.contact'))
            
        except Exception as e:
            current_app.logger.error(f"Failed to send email: {str(e)}")
            # Log to console as fallback
            print(f"\n--- CONTACT FORM SUBMISSION ---")
            print(f"Name: {name}")
            print(f"Email: {email}")
            print(f"Subject: {subject}")
            print(f"Message: {message}")
            print(f"--- END SUBMISSION ---\n")
            
            flash('Message received! (Email service temporarily unavailable)', 'info')
            return redirect(url_for('contact.contact'))
    
    return render_template('contact.html')
